// helpers.mjs -- page actions shared by scenes.
export async function dragBy(page, selector, dx) {
  const box = await page.$eval(selector, (el) => { const r = el.getBoundingClientRect(); return { x: r.x + r.width / 2, y: r.y + r.height / 2 }; });
  await page.mouse.move(box.x, box.y);
  await page.mouse.down();
  for (let i = 1; i <= 10; i += 1) await page.mouse.move(box.x + (dx * i) / 10, box.y);
  await page.mouse.up();
}
/** The side panel as wide as it goes: the main column at its floor. */
export async function edgeKey(page, selector, key) { await page.focus(selector); await page.keyboard.press(key); }
export const panelWidest = (page) => edgeKey(page, ".side-panel-resize", "End");
/** The side panel at its own floor. */
export const panelNarrowest = (page) => edgeKey(page, ".side-panel-resize", "Home");
/** The sidebar at its widest (400) or narrowest (200). */
export const sidebarWidest = (page) => edgeKey(page, ".sidebar-resize", "End");
export const sidebarNarrowest = (page) => edgeKey(page, ".sidebar-resize", "Home");
export async function click(page, selector) { await page.waitForSelector(selector, { timeout: 4000 }); await page.click(selector); }
export async function clickText(page, text, scope = "button, a, [role=button], [role=tab], [role=menuitem], li, div") {
  const ok = await page.evaluate((text, scope) => { const el = [...document.querySelectorAll(scope)].reverse().find((e) => e.innerText?.trim() === text); el?.click(); return !!el; }, text, scope);
  if (!ok) throw new Error(`no element with text ${text}`);
}
export async function widths(page) {
  return page.evaluate(() => Object.fromEntries([".desktop-sidebar", ".desktop-plan-main", ".side-panel-resize", ".desktop-plan"].map((s) => { const r = document.querySelector(s)?.getBoundingClientRect(); return [s, r ? `${Math.round(r.left)}..${Math.round(r.right)} (${Math.round(r.width)})` : "none"]; })));
}
