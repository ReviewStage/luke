// geometry.js -- in-page checks for overlaps, word-per-line wraps, clipped controls, horizontal scroll and unreadable truncation.
// Evaluated in the page; returns an array of findings.
(() => {
  const findings = [];
  const W = window.innerWidth;
  const H = window.innerHeight;
  const describe = (el) => {
    const cls = typeof el.className === "string" ? el.className.trim().split(/\s+/).slice(0, 3).join(".") : "";
    const text = (el.innerText || el.getAttribute("aria-label") || "").trim().replace(/\s+/g, " ").slice(0, 40);
    return `${el.tagName.toLowerCase()}${cls ? "." + cls : ""}${text ? ` "${text}"` : ""}`;
  };
  const visible = (el) => {
    for (let at = el; at && at !== document.documentElement; at = at.parentElement) {
      const s = getComputedStyle(at);
      if (s.display === "none" || s.visibility === "hidden" || s.visibility === "collapse") return false;
      if (Number(s.opacity) < 0.05) return false;
      if (at.hasAttribute("inert") && at !== el) return false;
      if (at.getAttribute("aria-hidden") === "true" && at.closest("[data-harness-ignore]")) return false;
    }
    return true;
  };
  // The part of an element's box that is not clipped by an ancestor or the viewport.
  const visibleRect = (el) => {
    const r = el.getBoundingClientRect();
    let left = r.left, top = r.top, right = r.right, bottom = r.bottom;
    for (let at = el.parentElement; at; at = at.parentElement) {
      const s = getComputedStyle(at);
      if (s.overflowX !== "visible" || s.overflowY !== "visible" || s.clipPath !== "none" || s.contain.includes("paint")) {
        const a = at.getBoundingClientRect();
        if (s.overflowX !== "visible") { left = Math.max(left, a.left); right = Math.min(right, a.right); }
        if (s.overflowY !== "visible") { top = Math.max(top, a.top); bottom = Math.min(bottom, a.bottom); }
      }
    }
    left = Math.max(left, 0); top = Math.max(top, 0); right = Math.min(right, W); bottom = Math.min(bottom, H);
    return { left, top, right, bottom, width: right - left, height: bottom - top, full: r };
  };
  const hasOwnText = (el) => [...el.childNodes].some((n) => n.nodeType === 3 && n.textContent.trim().length > 0);
  const controls = [...document.querySelectorAll("button, a[href], input, select, textarea, [role=button], [role=tab], [role=menuitem], [role=checkbox], [role=switch], [contenteditable=true]")].filter(visible);
  const texts = [...document.querySelectorAll("body *")].filter((el) => hasOwnText(el) && visible(el) && !["SCRIPT", "STYLE", "TITLE"].includes(el.tagName));

  // 1. Horizontal scroll.
  const se = document.scrollingElement;
  if (se.scrollWidth > W + 1) findings.push({ kind: "horizontal-scroll", what: "document", detail: `${se.scrollWidth} > ${W}` });
  for (const el of document.querySelectorAll("body *")) {
    const s = getComputedStyle(el);
    if ((s.overflowX === "auto" || s.overflowX === "scroll") && el.scrollWidth > el.clientWidth + 2 && el.clientWidth > 0 && visible(el)) {
      if (el.matches("pre, code, pre *, .code-block *, [data-code], table, .cm-scroller, .xterm *, [class*=tab-strip], [class*=tabs], [role=tablist]")) continue;
      findings.push({ kind: "horizontal-scroll", what: describe(el), detail: `${el.scrollWidth} > ${el.clientWidth}` });
    }
  }

  // 2. Text spilling out of its box or clipped, and unreadable truncation.
  for (const el of texts) {
    const s = getComputedStyle(el);
    const vr = visibleRect(el);
    if (vr.width <= 0 || vr.height <= 0) continue;
    if (s.textOverflow === "ellipsis" && el.scrollWidth > el.clientWidth + 1) {
      const shown = el.clientWidth;
      const chars = (el.textContent || "").trim().length;
      const charW = parseFloat(s.fontSize) * 0.55;
      const fits = Math.floor(shown / charW);
      if (fits < Math.min(6, chars)) findings.push({ kind: "unreadable-truncation", what: describe(el), detail: `${shown}px shows ~${fits} of ${chars} chars`, rect: vr });
    }
  }

  // 3. Word-per-line wraps.
  for (const el of texts) {
    if (el.closest("pre, code, .cm-editor, [data-code], .xterm")) continue;
    const vr = visibleRect(el);
    if (vr.width <= 0 || vr.height <= 0) continue;
    const words = (el.innerText || "").trim().split(/\s+/).filter(Boolean);
    if (words.length < 3) continue;
    const rects = [];
    const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
    for (let n = walker.nextNode(); n; n = walker.nextNode()) {
      if (!n.textContent.trim()) continue;
      const range = document.createRange();
      range.selectNodeContents(n);
      for (const r of range.getClientRects()) if (r.width > 0) rects.push(r);
    }
    const mids = rects.map((r) => (r.top + r.bottom) / 2).sort((a, b) => a - b);
    const lineH = parseFloat(getComputedStyle(el).lineHeight) || parseFloat(getComputedStyle(el).fontSize) * 1.3;
    let lines = 0, last = -1e9;
    for (const m of mids) { if (m - last > lineH * 0.6) { lines += 1; last = m; } }
    if (lines >= 3 && words.length / lines <= 1.5) findings.push({ kind: "word-per-line", what: describe(el), detail: `${words.length} words on ${lines} lines in ${Math.round(el.getBoundingClientRect().width)}px`, rect: vr });
  }

  // 4. Controls clipped by an ancestor (partly hidden) or squeezed under their content.
  for (const el of controls) {
    const vr = visibleRect(el);
    const r = vr.full;
    if (r.width < 1 || r.height < 1) continue;
    if (vr.width <= 0 || vr.height <= 0) continue; // fully scrolled away
    const clippedW = r.width - vr.width, clippedH = r.height - vr.height;
    if ((clippedW > 2 && clippedW < r.width) || (clippedH > 2 && clippedH < r.height && r.height < 60)) {
      // Ignore controls merely scrolled partly out of a vertical scroller.
      const scrolledY = clippedH > 2 && clippedW <= 2;
      if (!scrolledY) findings.push({ kind: "clipped-control", what: describe(el), detail: `visible ${Math.round(vr.width)}×${Math.round(vr.height)} of ${Math.round(r.width)}×${Math.round(r.height)}`, rect: vr });
    }
    if (el.scrollWidth > el.clientWidth + 2 && getComputedStyle(el).overflowX === "visible" && el.clientWidth > 0) {
      findings.push({ kind: "spilled-control", what: describe(el), detail: `content ${el.scrollWidth} > box ${el.clientWidth}`, rect: vr });
    }
  }

  // 5. Overlaps between controls, and between a control and text.
  const boxes = [...controls, ...texts.filter((t) => !t.closest("button, a, [role=button], [role=tab], [role=menuitem]"))]
    .map((el) => ({ el, r: visibleRect(el), lines: getComputedStyle(el).display === "inline" ? [...el.getClientRects()] : null }))
    .filter(({ r }) => r.width > 2 && r.height > 2);
  const stickySeen = new Set();
  const ignore = (a) => a.closest("[role=tooltip], .tooltip-card, [data-harness-ignore]");
  for (let i = 0; i < boxes.length; i += 1) {
    for (let j = i + 1; j < boxes.length; j += 1) {
      const a = boxes[i], b = boxes[j];
      if (a.el.contains(b.el) || b.el.contains(a.el)) continue;
      const x = Math.min(a.r.right, b.r.right) - Math.max(a.r.left, b.r.left);
      const y = Math.min(a.r.bottom, b.r.bottom) - Math.max(a.r.top, b.r.top);
      if (x <= 3 || y <= 3) continue;
      if (a.lines || b.lines) {
        const la = a.lines ?? [a.r], lb = b.lines ?? [b.r];
        const hit = la.some((p) => lb.some((q) => Math.min(p.right, q.right) - Math.max(p.left, q.left) > 3 && Math.min(p.bottom, q.bottom) - Math.max(p.top, q.top) > 3));
        if (!hit) continue;
      }
      const pinned = (el) => { for (let at = el; at && at !== document.body; at = at.parentElement) { const p = getComputedStyle(at).position; if (p === "sticky" || p === "fixed") return at; } return null; };
      const pa = pinned(a.el), pb = pinned(b.el);
      if (pa !== pb) {
        const pin = pa ?? pb;
        const key = describe(pin);
        if (!stickySeen.has(key)) { stickySeen.add(key); findings.push({ kind: "sticky-over-content", what: key, detail: `content scrolls under it (${getComputedStyle(pin).backgroundColor}, mask ${getComputedStyle(pin).maskImage})` }); }
        continue;
      }
      // Skip pairs where one is a floating overlay standing over the page (menus, popovers, dialogs), unless both are in it.
      const layer = (el) => el.closest("[role=dialog], [role=menu], [role=listbox], [popover], .popover, [data-radix-popper-content-wrapper], .toast, [role=status], [role=alert]");
      if (layer(a.el) !== layer(b.el)) continue;
      if (ignore(a.el) || ignore(b.el)) continue;
      // Is either actually painted on top? Probe the centre of the intersection.
      const cx = Math.max(a.r.left, b.r.left) + x / 2, cy = Math.max(a.r.top, b.r.top) + y / 2;
      const top = document.elementFromPoint(cx, cy);
      if (!top) continue;
      const aOn = a.el.contains(top) || top.contains(a.el), bOn = b.el.contains(top) || top.contains(b.el);
      if (!aOn && !bOn) continue;
      findings.push({ kind: "overlap", what: `${describe(a.el)} ⟷ ${describe(b.el)}`, detail: `${Math.round(x)}×${Math.round(y)}px`, rect: { left: Math.max(a.r.left, b.r.left), top: Math.max(a.r.top, b.r.top), width: x, height: y } });
    }
  }
  // De-duplicate by kind+what.
  const seen = new Set();
  return findings.filter((f) => { const k = f.kind + f.what; if (seen.has(k)) return false; seen.add(k); return true; });
})();
