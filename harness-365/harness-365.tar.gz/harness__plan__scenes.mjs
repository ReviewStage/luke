// scenes.mjs -- the plan area's scenes: the Plan document, its editor, history, menus, and the side panel's tabs at every floor.
import { panelNarrowest, panelWidest, sidebarWidest } from "../helpers.mjs";

const PLAN = "0f6a2c4e-8b1d-4e3f-9a57-1c2b3d4e5f60";
const AGENT_A = "8c1a6a4f-3d2e-4d8b-8b66-6f4c7a2e3b21";

/** The side panel as kept: open (or not) on `tab`, with Board, Code, Call, and agent A's Changes open on the plan. */
const store = (tab = "code", open = true) => ({
  "luke.sidePanel": {
    open,
    tabs: ["board", "code", "call"],
    ...(tab === undefined ? {} : { tab }),
    width: 400,
    plans: { [PLAN]: { opened: ["board", "code", "call"], closed: [], changes: [{ changes: AGENT_A }] } },
  },
});

const FLOORS = {
  main280: { window: { width: 1160, height: 720 }, setup: async (p, sleep) => { await sidebarWidest(p); await sleep(250); await panelWidest(p); } },
  main423: { window: { width: 760, height: 640 }, setup: async (p) => { await panelWidest(p); } },
  panel280: { window: { width: 760, height: 640 }, setup: async (p) => { await panelNarrowest(p); } },
  full760: { window: { width: 760, height: 640 }, closed: true, setup: async () => undefined },
  "full760-pinned": { window: { width: 1160, height: 720 }, closed: true, setup: async (p) => { await sidebarWidest(p); } },
  wide: { window: { width: 1400, height: 800 }, setup: async () => undefined },
};

async function pick(page, text, scope = ".menu-item, [role=menuitem], [role=option]") {
  const ok = await page.evaluate((text, scope) => {
    const el = [...document.querySelectorAll(scope)].find((e) => e.innerText?.trim().startsWith(text));
    el?.click();
    return !!el;
  }, text, scope);
  if (!ok) throw new Error(`no menu item ${text}`);
}
const press = async (p, sel) => { await p.waitForSelector(sel, { timeout: 4000 }); await p.click(sel); };
const scrollDoc = (p, frac) => p.$eval(".plan-document-scroll", (el, frac) => { el.scrollTop = el.scrollHeight * frac; }, frac);
const scrollSide = (p, frac) => p.evaluate((frac) => { for (const el of document.querySelectorAll(".side-panel *")) if (el.scrollHeight > el.clientHeight + 20 && getComputedStyle(el).overflowY !== "visible") el.scrollTop = el.scrollHeight * frac; }, frac);

/** A scene at a floor: `act` runs after the floor is reached. */
function scene(id, floor, { title = id, profile = "planning-work", tab = "code", act, height, data = {}, after, themes } = {}) {
  const f = FLOORS[floor];
  return {
    id: `${id}--${floor}${height ? `-h${height}` : ""}`,
    title: `${title} @ ${floor}`,
    window: { ...f.window, ...(height ? { height } : {}) },
    storage: store(tab, !f.closed),
    data: { profile, ...data },
    after,
    themes,
    steps: async (p, { sleep }) => {
      await f.setup(p, sleep);
      await sleep(300);
      if (act) await act(p, sleep);
    },
  };
}

const MAIN = ["main280", "main423", "full760"];
const SIDE = ["panel280", "main280"];
const REF = ["wide"];
const all = (floors, id, opts) => floors.map((floor) => scene(id, floor, opts));

// Main column acts.
const startMenu = async (p, sleep) => { await press(p, "button[aria-label='Choose a model to start with']"); await sleep(400); };
const actionsMenu = async (p, sleep) => { await press(p, "button[aria-label='Task actions']"); await sleep(400); };
const outline = async (p, sleep) => { await press(p, "button.summary-toggle"); await sleep(400); };
const titleMenu = async (p, sleep) => { await press(p, "button[aria-label='Title actions']"); await sleep(400); };
const mainAdd = async (p, sleep) => { await press(p, ".desktop-plan-main button.tab-add"); await sleep(400); };
const moveDialog = async (p, sleep) => { await actionsMenu(p, sleep); await pick(p, "Move to workspace"); await sleep(600); };
const repoPicker = async (p, sleep) => { await actionsMenu(p, sleep); await pick(p, "Change repository"); await sleep(800); };
const history = async (p, sleep) => { await press(p, ".plan-edit-link"); await sleep(1200); };
const historyOlder = async (p, sleep) => {
  await history(p, sleep);
  const ok = await p.evaluate(() => { const rows = [...document.querySelectorAll(".version-log button, .version-log a, .version-log [role=option]")].filter((r) => r.innerText.includes("Restored")); rows[0]?.click(); return rows.length; });
  if (!ok) throw new Error("no restored row");
  await sleep(1000);
};
const edit = async (p, sleep) => { const ps = await p.$$(".plan-body p"); await ps[0].click(); await sleep(1500); };
const editTyped = async (p, sleep) => {
  await edit(p, sleep);
  await p.keyboard.press("End");
  await p.keyboard.type(" (draft)");
  await sleep(4000);
  const found = await p.evaluate(() => { const n = document.querySelector(".plan-editor-note"); n?.scrollIntoView({ block: "center" }); return !!n; });
  if (!found) throw new Error("no editor note");
};
const editTable = async (p, sleep) => { await scrollDoc(p, 1); await sleep(200); const cells = await p.$$(".plan-body td"); await cells[cells.length - 1]?.click(); await sleep(1500); };

// Side panel acts.
const sideAdd = async (p, sleep) => { await press(p, ".side-panel button.tab-add"); await sleep(400); };
const openFromAdd = (text) => async (p, sleep) => { await sideAdd(p, sleep); await pick(p, text); await sleep(1200); };
const openFile = async (p, sleep) => { await press(p, ".side-panel button[aria-label='Open file']"); await sleep(1200); };
const manyTabs = async (p, sleep) => {
  await openFile(p, sleep);
  await openFromAdd("Invitation email")(p, sleep);
  await openFromAdd("Withdraw an invite")(p, sleep);
};

export const scenes = [
  // The Plan document read view: breadcrumb, title, toolbar, tab strip, rail, call bar.
  ...all([...MAIN, "full760-pinned", "wide"], "doc", { title: "Plan document read view" }),
  scene("doc", "main280", { title: "Plan document read view (short window)", height: 520 }),
  ...all(MAIN, "doc-mid", { title: "Plan document scrolled to Approach/Interfaces", act: async (p) => scrollDoc(p, 0.3) }),
  ...all(MAIN, "doc-end", { title: "Plan document scrolled to Rollout (ordered list, tasks, quote, table)", act: async (p) => scrollDoc(p, 1) }),
  ...all(MAIN, "doc-nocall", { title: "Plan document, no call", data: { call: false } }),
  // Toolbar menus and popovers.
  ...all(MAIN, "start-menu", { title: "Start split-button menu", act: startMenu }),
  ...all(MAIN, "actions-menu", { title: "Plan ⋯ menu", act: actionsMenu }),
  ...all(MAIN, "outline", { title: "Outline (summary) popover", act: outline }),
  ...all(MAIN, "title-menu", { title: "Title ⋯ menu", act: titleMenu }),
  ...all(MAIN, "main-add", { title: "Main tab strip + menu", act: mainAdd }),
  ...all(MAIN, "move", { title: "Move to workspace dialog", act: moveDialog }),
  ...all(MAIN, "repo", { title: "Change repository picker", act: repoPicker }),
  // Editing.
  ...all(MAIN, "edit", { title: "Plan editor (editing mode)", act: edit }),
  ...all(MAIN, "edit-conflict", { title: "Plan editor with Luke's-change conflict note", act: editTyped, data: { edit: "conflict" } }),
  ...all(MAIN, "edit-failed", { title: "Plan editor with failed-save note", act: editTyped, data: { edit: "failed" } }),
  ...all(MAIN, "edit-table", { title: "Plan editor in the table", act: editTable }),
  // Version history.
  ...all([...MAIN, "full760-pinned"], "history", { title: "Version history", act: history }),
  ...all(MAIN, "history-older", { title: "Version history, an older (restore) version chosen", act: historyOlder }),
  // Side panel tabs.
  ...all(SIDE, "side-code", { title: "Side panel: Code tab", tab: "code" }),
  ...all(SIDE, "side-board", { title: "Side panel: Board tab", tab: "board", profile: "planning-board", after: 2500 }),
  ...all(SIDE, "side-call-transcript", { title: "Side panel: Call tab (transcript)", tab: "call", profile: "planning-transcript" }),
  ...all(SIDE, "side-call-work", { title: "Side panel: Call tab (work)", tab: "call", profile: "planning-work" }),
  ...all(SIDE, "side-call-work-end", { title: "Side panel: Call tab (work) scrolled", tab: "call", profile: "planning-work", act: async (p) => scrollSide(p, 1) }),
  ...all(SIDE, "side-changes", { title: "Side panel: Changes tab", tab: { changes: AGENT_A }, after: 1500 }),
  ...all(SIDE, "side-changes-end", { title: "Side panel: Changes tab scrolled", tab: { changes: AGENT_A }, act: async (p, sleep) => { await sleep(1200); await scrollSide(p, 0.5); } }),
  ...all(SIDE, "side-file", { title: "Side panel: File tab", act: openFile }),
  ...all(SIDE, "side-page", { title: "Side panel: page tab", act: openFromAdd("Invitation email") }),
  ...all(SIDE, "side-page-source", { title: "Side panel: page tab, source view", act: async (p, sleep) => {
    await openFromAdd("Invitation email")(p, sleep);
    const ok = await p.evaluate(() => { const b = [...document.querySelectorAll(".side-panel button")].find((x) => x.getAttribute("aria-label") === "View source"); b?.click(); return b?.getAttribute("aria-label"); });
    if (!ok) throw new Error("no source toggle");
    await sleep(1000);
  } }),
  ...all(SIDE, "side-terminal", { title: "Side panel: Terminal tab", act: openFromAdd("Withdraw an invite") }),
  ...all(SIDE, "side-terminal-stopped", { title: "Side panel: Terminal tab, sandbox stopped", act: openFromAdd("Withdraw an invite"), data: { sandbox: "stopped" } }),
  ...all(SIDE, "side-add", { title: "Side panel + menu", act: sideAdd }),
  // Comfortable-width references for the side panel's heavier tabs.
  ...all(REF, "side-changes", { title: "Side panel: Changes tab (reference)", tab: { changes: AGENT_A }, after: 1500, themes: ["light"] }),
  ...all(REF, "side-file", { title: "Side panel: File tab (reference)", act: openFile, themes: ["light"] }),
  ...all(REF, "side-terminal", { title: "Side panel: Terminal tab (reference)", act: openFromAdd("Withdraw an invite"), themes: ["light"] }),
  ...all(SIDE, "side-many", { title: "Side panel tab strip with many tabs", act: manyTabs }),
];
