// build.mjs -- bundle the harness bridge for one area: node build.mjs <area> [outfile]
import { build } from "esbuild";
import path from "node:path";
const root = path.dirname(new URL(import.meta.url).pathname);
const area = process.argv[2] ?? "base";
await build({
  entryPoints: [path.join(root, "stub.ts")],
  bundle: true, format: "iife", platform: "browser", target: "chrome130",
  outfile: process.argv[3] ?? `/home/vercel-sandbox/harness/stub-${area}.js`,
  tsconfig: path.join(root, "../tsconfig.json"),
  alias: { "harness-area": path.join(root, "areas", area, "area.ts") },
  logLevel: "warning",
});
