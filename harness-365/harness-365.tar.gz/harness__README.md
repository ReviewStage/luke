# Narrow-width audit harness

The REAL compiled Luke renderer (`apps/desktop/dist/renderer`, built from `origin/main`) runs in
headless Chrome. A stubbed `window.luke` bridge hands it a signed-in fixture app state and answers
its acts (the renderer's one IO channel) from per-area fixture modules. You drive it like a user
(clicks, keys), at the real layout floors, in light and dark, and get 2× PNG frames plus a
geometry report per frame.

**Do not edit anything under `/home/vercel-sandbox/luke` except your own area folder
`apps/desktop/.harness/areas/<area>/`** (untracked, excluded from git). Write output only under
`/home/vercel-sandbox/harness/<area>/`. Other agents run beside you.

## Pieces

- `apps/desktop/.harness/stub.ts`: the bridge. Snapshot = `signedInAs(...)` from
  `apps/desktop/src/testing/app-state.ts`, run in fixture mode (`fixtureMode: true`, profile from
  `window.__scene.profile`, default `"planning"`), which makes the Plans/sidebar draw the synthetic
  plans of `apps/desktop/src/renderer/planning/planning-fixture.ts` (task "Teammate invitations"
  open with its side panel on Code). Acts not answered by your area are REFUSED (the renderer
  shows its refusal/error state).
- `apps/desktop/.harness/areas/<area>/area.ts`: exports `answers: Answers` (typed per act kind:
  `(payload, scene) => ActResultFor<Kind>`) and `state(snapshot, scene)` to shape the app state
  (e.g. `inbox`, `codingAgents`, `update`, `account` for signed-out). Copy `areas/base/` (with its
  `tsconfig.json`) to start. Typecheck: `cd apps/desktop/.harness && npx tsc --noEmit -p areas/<area>/tsconfig.json`.
  Build: `node apps/desktop/.harness/build.mjs <area>` → `/home/vercel-sandbox/harness/stub-<area>.js`.
  Look at existing tests (`apps/desktop/src/renderer/**/*.test.ts`, `#testing/*` fixtures,
  `packages/*/src/testing`) for valid answer values; act kinds and result types are in
  `packages/host/src/acts.ts`. Long-poll reads (e.g. `codingAgents.messages` past its cursor)
  must answer once and then return `never()` from `../../types`, or they loop.
  Timestamps: use realistic epoch ms (e.g. `Date.UTC(2026, 9, 15, 14, 20)`).
- `/home/vercel-sandbox/harness/shoot.mjs`: runs scenes.
  `node /home/vercel-sandbox/harness/shoot.mjs --scenes <your scenes.mjs> --stub /home/vercel-sandbox/harness/stub-<area>.js --out /home/vercel-sandbox/harness/<area>/frames [--only id1,id2] [--themes light,dark]`
  A scene: `{ id, title, window: { width, height }, storage: { localStorageKey: value }, data: {…window.__scene…}, steps: async (page, { sleep }) => {…}, clip?: selector, settle?, after? }`.
  `page` is a puppeteer-core Page. Helpers in `/home/vercel-sandbox/harness/helpers.mjs`
  (`panelWidest`, `panelNarrowest`, `sidebarWidest`, `sidebarNarrowest`, `click`, `clickText`, `widths`).
  Frames are `<id>--<theme>.png` at 2×; `report*.json` holds per-frame `findings` from
  `geometry.js`: `overlap`, `word-per-line`, `clipped-control`, `spilled-control`,
  `horizontal-scroll`, `unreadable-truncation`, `sticky-over-content`. The checker has false
  positives and misses things: **always look at the frames yourself** (Read the PNG) and judge.
- The page's console is not shown; `errors` in the report carry page errors and step failures.

## The layout floors (measured in the real app)

| Floor | How to reach it | Main column | Side panel |
| --- | --- | --- | --- |
| `main280` (Dean's case) | window 1160×720, `sidebarWidest` (400), then `panelWidest` | 280 | 480 |
| `main423` | window 760×640 (min window, sidebar folds below 1120), `panelWidest` | 423 | 337 |
| `panel280` | window 760×640, `panelNarrowest` | 480 | 280 |
| `full760` | window 760×640, side panel closed / a full page | 760 | — |
| `full760-pinned` | window 1160×720, `sidebarWidest`; full page | 760 | — |
| short | any of the above at height 520 (the window's min height) | | |

The window's min size is 760×520 (`apps/desktop/src/main/window/panel-manager.ts`). Sidebar 200–400
(default 264), folding to an overlay below a 1120px window. The main column beside the side
panel keeps `--document-reserve` (280px beside the open sidebar; 423px when folded). Side panel
min 280, default 400. The floating call window is 264×92 (`call.html`, role `call`).

## What to record

Every overlap, word-per-line wrap, clipped control, horizontal scroll, unreadable truncation
(a label cut to a letter or two with no way to read it), control pushed off its row, content
that collides, plus anything that just looks broken at the floor. Compare against a comfortable
width (e.g. 1400 wide) when unsure whether it's a narrow-width problem.

Write `/home/vercel-sandbox/harness/<area>/findings.json`:

```json
[{
  "title": "Archived banner: Unarchive overlaps the text, text wraps a word per line",
  "severity": "high | medium | low",
  "surface": "Task › agent tab (archived)",
  "floor": "main280",
  "what": "One or two sentences of what breaks, in plain words.",
  "frames": { "light": "/home/vercel-sandbox/harness/<area>/frames/x--light.png", "dark": ".../x--dark.png" },
  "cause": "file:line of the component and CSS rule responsible, and why it breaks",
  "fix": "the fix you'd suggest, reusing a shared pattern (container query on the component, action drops below text / icon-button with tooltip, min-width:0 + truncation + tooltip, toolbar → ⋯ overflow, or a layout floor)"
}]
```

Severity: high = overlap/unusable/clipped primary action; medium = ugly wraps, unreadable
truncation, lost secondary controls; low = cosmetic. Also list in `findings.json`'s sibling
`clean.json` the surfaces you checked that are fine at every floor (just titles + one frame), so
the audit shows coverage. Keep scene scripts in `/home/vercel-sandbox/harness/<area>/scenes.mjs`
so the same frames can be re-shot after fixes.
