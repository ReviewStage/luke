// stub.ts -- a window.luke bridge for driving the compiled renderer in headless Chrome.
import { ACT_OUTCOME_STATUS, type Act, type ActKind, type ActOutcome } from "@luke/host/acts";
import type { AppStateSnapshot } from "@luke/host/app-state";
import { signedInAs } from "#testing/app-state";
import { answers, state } from "harness-area";

declare global {
  interface Window {
    __acts: string[];
    __scene: Record<string, unknown> | undefined;
    __state: AppStateSnapshot;
    __push: (snapshot: AppStateSnapshot) => void;
  }
}

const base = signedInAs({ id: "user-ada", email: "ada@example.com", name: "Ada Lovelace" });
let snapshot: AppStateSnapshot = {
  ...base,
  run: { ...base.run, profile: (window.__scene?.profile as string) ?? "planning", captureMode: true, fixtureMode: true },
};
snapshot = state(snapshot, window.__scene ?? {});
window.__state = snapshot;
window.__acts = [];
const listeners = new Set<(value: AppStateSnapshot) => void>();
window.__push = (next) => {
  snapshot = next;
  window.__state = next;
  for (const listener of listeners) listener(next);
};

async function act(request: Act): Promise<ActOutcome> {
  window.__acts.push(request.kind);
  const answer = answers[request.kind as ActKind];
  if (answer === undefined) return { status: ACT_OUTCOME_STATUS.REFUSED, reason: "Not in the harness." };
  try {
    // biome-ignore lint: harness
    const value = await (answer as (payload: unknown, scene: unknown) => unknown)("payload" in request ? request.payload : undefined, window.__scene ?? {});
    return { status: ACT_OUTCOME_STATUS.DONE, value } as ActOutcome;
  } catch (error) {
    return { status: ACT_OUTCOME_STATUS.REFUSED, reason: String(error) };
  }
}

const noop = () => () => undefined;
const bridge: Record<string, unknown> = {
  act,
  requestAppState: async () => snapshot,
  onAppState: (callback: (value: AppStateSnapshot) => void) => {
    listeners.add(callback);
    return () => listeners.delete(callback);
  },
};
window.luke = new Proxy(bridge, {
  get: (target, key: string) => {
    if (key in target) return target[key];
    if (key.startsWith("on")) return noop;
    return () => undefined;
  },
}) as unknown as Window["luke"];
