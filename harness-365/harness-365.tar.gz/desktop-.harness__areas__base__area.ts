// area.ts -- an area's fixture answers and app state for the harness. Copy this folder to start an area.
import type { AppStateSnapshot } from "@luke/host/app-state";
import type { Answers } from "../../types";

export const answers: Answers = {};

/** The app state this area's scenes start from; `scene` is `window.__scene` as the scene set it. */
export function state(snapshot: AppStateSnapshot, _scene: Record<string, unknown>): AppStateSnapshot {
  return snapshot;
}
