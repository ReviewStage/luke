// area.ts -- the plan area's fixtures: the fixture plan with long, realistic names, its agents, history, files, and call.
import { CODING_AGENT_STATUS } from "@luke/features/coding-agent-wire";
import { MODEL_PROVIDER } from "@luke/features/models-wire";
import { PLAN_ACTOR, type Plan, type PlanRevisionLine } from "@luke/features/plan-wire";
import { PLANNING_READ, type PlanningView } from "@luke/features/planning-view";
import { WORKSPACE_ROLE, type Workspace } from "@luke/features/workspace-wire";
import type { AppStateSnapshot } from "@luke/host/app-state";
import { IDLE_VOICE_VIEW } from "@luke/voice/voice-view";
import {
  FIXTURE_PLANNING_CALL,
  fixturePlanningView,
} from "../../../src/renderer/planning/planning-fixture";
import { conversationOf } from "#testing/plan-work";
import { type Answers, never } from "../../types";

const ME = "user-ada";
const PLAN_ID = "0f6a2c4e-8b1d-4e3f-9a57-1c2b3d4e5f60";
const REPO = "northwind-platform/customer-identity-and-access-management-service";
const TITLE = "Let members invite teammates by email with expiring single-use links";
const AGENT_A = "8c1a6a4f-3d2e-4d8b-8b66-6f4c7a2e3b21";
const AGENT_B = "9d2b7b5a-4e3f-4e9c-9c77-7a5d8b3f4c32";
const AGENT_C = "ae3c8c6b-5f4a-4fad-8d88-8b6e9c4a5d43";
const PAGE_ID = "b1c2d3e4-f5a6-4b7c-8d9e-0f1a2b3c4d5e";
const T = (h: number, m: number, d = 15) => Date.UTC(2026, 9, d, h, m);

const TEAM: Workspace = {
  id: "workspace-northwind",
  name: "Northwind Platform Infrastructure",
  slug: "northwind-platform",
  role: WORKSPACE_ROLE.ADMIN,
  github: { login: "northwind-platform", active: true },
};

const MEMBERS = [
  { userId: ME, name: "Ada Lovelace", email: "ada@example.com", role: WORKSPACE_ROLE.ADMIN },
  { userId: "user-grace", name: "Grace Hopper-Montgomery", email: "grace@example.com", role: WORKSPACE_ROLE.MEMBER },
  { userId: "user-kat", name: "Katherine Johnson", email: "kat@example.com", role: WORKSPACE_ROLE.MEMBER },
];

const EXTRA_BODY = [
  "## Rollout",
  "1. Ship `src/members/invite.ts` behind the `members.invitesByEmail` flag in `config/feature-flags/production.yaml`.",
  "2. Backfill `memberships.invited_by_user_id` from `audit_log_entries.actor_user_id` for every pending row.",
  "3. Turn the flag on for `northwind-platform/customer-identity-and-access-management-service` staging, then production.",
  "- [ ] Email template reviewed by design",
  "- [x] `POST /api/workspaces/:workspaceId/invitations/:invitationId/resend` returns 202",
  "> A withdrawn link reads \"This invite is no longer valid\" and grants nothing.",
  "| Case | Result |\n| --- | --- |\n| Link opened twice | `410 Gone` with `InviteError(\"no-longer-valid\")` |\n| Link opened after 7 days | `410 Gone` with `InviteError(\"expired\")` |",
].join("\n\n");

function longPlan(base: Plan): Plan {
  return {
    ...base,
    name: TITLE,
    repository: REPO,
    updatedAt: T(14, 20),
    document: { body: `${base.document.body}\n${EXTRA_BODY}\n`, assumptions: [] },
    lastEdit: { actor: PLAN_ACTOR.NOTETAKER, by: { userId: "user-grace", name: "Grace Hopper-Montgomery" }, at: T(14, 20), duringCall: true },
    agentEdits: [{ agentId: AGENT_A, label: "Model invites as pending memberships and send the email", at: T(13, 5) }],
  };
}

function longView(view: PlanningView): PlanningView {
  const plan = view.document.plan;
  const plans = view.plans.map((summary) =>
    summary.id === PLAN_ID ? { ...summary, name: TITLE, repository: REPO, updatedAt: T(14, 20) } : summary,
  );
  return {
    ...view,
    plans,
    workspaces: view.workspaces.map((workspace, index) => (index === 0 ? { ...workspace, name: TEAM.name } : workspace)),
    document: plan === undefined ? view.document : { status: PLANNING_READ.READY, plan: longPlan(plan) },
    shownCode: (view.shownCode ?? []).map((showing) => ({
      ...showing,
      code: { ...showing.code, repository: REPO, ref: { ...showing.code.ref, path: "packages/identity/src/members/invitations/accept-invite-by-token.ts" } },
    })),
    ...(view.work === undefined ? {} : { conversation: conversationOf(view.work) }),
    pages: [{ id: PAGE_ID, title: "Invitation email: copy, layout, and expiry wording for every locale", version: 3, at: T(13, 40) }],
  };
}

const agent = (id: string, title: string | null, status: (typeof CODING_AGENT_STATUS)[keyof typeof CODING_AGENT_STATUS], at: number) => ({
  id,
  planId: PLAN_ID,
  model: "anthropic/claude-opus-5.5",
  effort: "high",
  title,
  createdAt: at,
  status,
  turnId: null,
});

const PATCH = [
  "@@ -1,6 +1,8 @@",
  " import { db } from \"../../db\";",
  "+import { InviteError, type InvitationToken } from \"./invite-errors-and-token-types-for-the-acceptance-flow\";",
  " ",
  "-export async function acceptInvite(token: string) {",
  "+export async function acceptInvite(token: InvitationToken, acceptingUserId: string): Promise<Membership> {",
  "   const invite = await db.invites.find(token);",
  "+  if (invite === undefined || invite.acceptedAt !== null || invite.withdrawnAt !== null) throw new InviteError(\"no-longer-valid\");",
  "   return invite;",
  " }",
].join("\n");

const files = [
  "packages/identity/src/members/invitations/accept-invite-by-token.ts",
  "packages/identity/src/members/invitations/__tests__/accept-invite-by-token.test.ts",
  "packages/database/migrations/20261015142000_add_pending_state_and_invited_by_to_memberships/migration.sql",
  "apps/web/server/routes/api/workspaces/[workspaceId]/invitations/[invitationId]/resend.ts",
].map((path, index) => ({
  path,
  previousPath: index === 3 ? "apps/web/server/routes/api/workspaces/[workspaceId]/invitations/resend.ts" : null,
  status: index === 3 ? ("renamed" as const) : index === 2 ? ("added" as const) : ("modified" as const),
  additions: 38 + index * 12,
  deletions: 4 + index,
  patch: PATCH,
  omitted: null,
}));

const REVISION_LINES: PlanRevisionLine[] = [
  { seq: 7, lastEdit: { actor: PLAN_ACTOR.NOTETAKER, by: { userId: "user-grace", name: "Grace Hopper-Montgomery" }, at: T(14, 20), duringCall: true }, startedAt: T(14, 2), changes: 12, callId: "3c5e7a9b-1d2f-4a6c-8e0b-2d4f6a8c0e1a" },
  { seq: 6, lastEdit: { actor: PLAN_ACTOR.AGENT, label: "Model invites as pending memberships and send the email", agentId: AGENT_A, at: T(13, 5), duringCall: false }, agentId: AGENT_A, startedAt: T(12, 58), changes: 4 },
  { seq: 5, lastEdit: { actor: PLAN_ACTOR.DEVELOPER, by: { userId: ME, name: "Ada Lovelace" }, at: T(11, 30), duringCall: false }, startedAt: T(11, 10), changes: 27, restoredFrom: { seq: 2, at: T(9, 0, 14) } },
  { seq: 4, lastEdit: { actor: PLAN_ACTOR.DEVELOPER, by: { userId: "user-kat", name: "Katherine Johnson" }, at: T(10, 2), duringCall: false }, startedAt: T(9, 50), changes: 3 },
  { seq: 3, lastEdit: { actor: PLAN_ACTOR.NOTETAKER, by: { userId: ME, name: "Ada Lovelace" }, at: T(16, 44, 14), duringCall: true }, startedAt: T(16, 20, 14), changes: 41 },
  { seq: 2, lastEdit: { actor: PLAN_ACTOR.DEVELOPER, by: { userId: ME, name: "Ada Lovelace" }, at: T(9, 0, 14), duringCall: false }, startedAt: T(8, 50, 14), changes: 8 },
  { seq: 1, lastEdit: { actor: PLAN_ACTOR.EARLIER, at: T(8, 40, 14), duringCall: false }, startedAt: T(8, 40, 14), changes: 1 },
];

let currentBody = "";
const FILE_LINES = [
  "import { db } from \"../../db\";",
  "import { InviteError } from \"./invite-errors-and-token-types-for-the-acceptance-flow\";",
  "",
  "// An invite link is good once, and for seven days; a withdrawn link reads as no longer valid.",
  "export async function acceptInvite(token: InvitationToken, acceptingUserId: string): Promise<Membership> {",
  "  const invite = await db.invites.find(token);",
  "  if (!invite || invite.acceptedAt) throw new InviteError(\"no-longer-valid\");",
  "  if (expired(invite)) throw new InviteError(\"expired\");",
  "  return db.members.add(invite.workspaceId, acceptingUserId);",
  "}",
];
const colour = (code: string) => code.split("\n").map((line) => [{ text: line }]);
let messagesAsked = new Set<string>();

export const answers: Answers = {
  "workspace.membersRead": () => MEMBERS,
  "workspace.formerMembersRead": () => [],
  "codingAgents.models": () => ({
    models: [
      { id: "anthropic/claude-opus-5.5", name: "Claude Opus 5.5", provider: MODEL_PROVIDER.ANTHROPIC, efforts: ["low", "medium", "high"], contextWindows: { standardTokens: 200_000, longTokens: 1_000_000 } },
      { id: "openai/gpt-5.5-codex", name: "GPT-5.5 Codex", provider: MODEL_PROVIDER.OPENAI, efforts: ["low", "medium", "high"] },
    ],
  }),
  "codingAgents.defaultRead": () => ({ choice: { model: "anthropic/claude-opus-5.5", effort: "high" } }),
  "codingAgents.shown": () => undefined as never,
  "codingAgents.list": (_payload, scene) =>
    scene.agents === false
      ? { agents: [] }
      : {
          agents: [
            agent(AGENT_A, "Model invites as pending memberships and send the email", CODING_AGENT_STATUS.COMPLETED, T(12, 50)),
            agent(AGENT_B, "Withdraw an invite from the members page as an admin", CODING_AGENT_STATUS.RUNNING, T(13, 30)),
            agent(AGENT_C, null, CODING_AGENT_STATUS.STARTING, T(14, 10)),
          ],
        },
  "codingAgents.messages": (payload) => {
    const key = JSON.stringify(payload);
    if (messagesAsked.has(payload.agentId)) return never();
    messagesAsked.add(payload.agentId);
    void key;
    return { messages: [], cursor: "0:0", status: CODING_AGENT_STATUS.COMPLETED, title: null } as never;
  },
  "codingAgents.changes": () => ({
    pullRequest: {
      url: `https://github.com/${REPO}/pull/4821`,
      files,
      truncated: false,
      author: { login: "luke-agents[bot]", bot: true, luke: true },
      reviewers: [
        { by: { login: "grace-hopper-montgomery", bot: false }, state: "approved" },
        { by: { login: "katherine-johnson-nasa", bot: false }, state: "changes-requested" },
      ],
      commitAuthors: [{ login: "ada-lovelace", bot: false }],
    },
  }),
  "codingAgents.pullRequest": () => ({
    repository: REPO,
    branch: "ada/invite-teammates-by-email-with-expiring-links",
    pullRequest: { number: 4821, title: "Invite teammates by email with expiring single-use links", url: `https://github.com/${REPO}/pull/4821`, state: "open", checks: "passing", additions: 186, deletions: 22, changedFiles: 4 },
  }),
  "planning.select": () => true,
  "planning.refresh": () => undefined as never,
  "planning.repositories": () => ({
    repositories: {
      installed: true,
      repositories: [
        { owner: "northwind-platform", name: "customer-identity-and-access-management-service", fullName: REPO, defaultBranch: "main", private: true, updatedAt: T(14, 0) },
        { owner: "northwind-platform", name: "billing-ledger-and-invoicing-pipeline", fullName: "northwind-platform/billing-ledger-and-invoicing-pipeline", defaultBranch: "main", private: true, updatedAt: T(10, 0) },
      ],
      installationUrl: "https://github.com/apps/luke/installations/new",
    },
  }),
  "planning.revisions": () => ({ revisions: REVISION_LINES }),
  "planning.revision": (payload) => {
    currentBody ||= (window.__state.planning.document.plan?.document.body ?? "");
    const previous = currentBody.replace("An invite expires after 7 days.", "An invite expires after 14 days.").replace(/## Rollout[\s\S]*/u, "");
    return { revision: { seq: payload.seq, document: { body: currentBody, assumptions: [] }, previous: payload.seq === 1 ? null : { body: previous, assumptions: [] } } };
  },
  "planning.file": (payload) => ({
    file: {
      path: payload.path,
      repository: REPO,
      branch: "ada/invite-teammates-by-email-with-expiring-links",
      firstLine: 1,
      lineCount: FILE_LINES.length,
      lines: FILE_LINES.map((line) => [{ text: line }]),
    },
  }),
  "planning.tree": (payload) => ({
    folder: {
      path: "path" in payload ? payload.path : "",
      repository: REPO,
      branch: "main",
      entries: [
        { name: "packages", kind: "folder" },
        { name: "apps", kind: "folder" },
        { name: "accept-invite-by-token.ts", kind: "file" },
        { name: "an-unusually-long-file-name-for-the-invitation-acceptance-flow.test.ts", kind: "file" },
      ],
      truncated: false,
    },
  }),
  "planning.pageSource": () => ({ lines: colour("<!doctype html>\n<html>\n  <body>\n    <h1>You're invited to Northwind Platform Infrastructure</h1>\n    <p>Grace Hopper-Montgomery invited you. This link works once and expires in 7 days.</p>\n  </body>\n</html>") }),
  "planning.colourCode": (payload) => colour(payload.code),
  "planning.skills": () => ({ skills: { repository: REPO, branch: "main", skills: [] } }),
  "planning.edit": (_payload, scene) =>
    scene.edit === "conflict"
      ? { conflict: { current: `${window.__state.planning.document.plan?.document.body ?? ""}\n- Luke added this line while you typed.\n` } }
      : scene.edit === "failed"
        ? { failure: "unanswered" }
        : { saved: true },
  "planning.messages": () => never(),
  "terminal.list": (_payload, scene) => ({
    sandbox: scene.sandbox === "stopped" ? "stopped" : "running",
    terminals:
      scene.sandbox === "stopped"
        ? []
        : [
            { id: "c1d2e3f4-a5b6-4c7d-8e9f-0a1b2c3d4e5f", title: "pnpm --filter @northwind/identity test --watch", command: "pnpm --filter @northwind/identity test --watch", cwd: "/vercel/sandbox/customer-identity-and-access-management-service", running: true },
            { id: "d2e3f4a5-b6c7-4d8e-9f0a-1b2c3d4e5f60", title: "zsh", command: "zsh", cwd: "/vercel/sandbox", running: true },
          ],
  }),
  "terminal.attach": () => never(),
};

/** The app state: a live (non-fixture) run whose view is the fixture plan with long names, mid-call. */
export function state(snapshot: AppStateSnapshot, scene: Record<string, unknown>): AppStateSnapshot {
  messagesAsked = new Set();
  const profile = (scene.profile as string | undefined) ?? "planning";
  const view = fixturePlanningView({ fixtureMode: true, profile });
  if (view === undefined || scene.fixture === true) return snapshot;
  const call = scene.call === false ? IDLE_VOICE_VIEW : { ...IDLE_VOICE_VIEW, ...FIXTURE_PLANNING_CALL, listening: true };
  return {
    ...snapshot,
    run: { ...snapshot.run, profile: "idle", fixtureMode: false, captureMode: false },
    planning: longView(view),
    voice: { ...snapshot.voice, view: call },
    account: { ...snapshot.account, id: ME } as AppStateSnapshot["account"],
  };
}
