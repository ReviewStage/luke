// shoot.mjs -- drive the compiled renderer through scenes in headless Chrome, writing frames and geometry reports.
// usage: node shoot.mjs --dist <apps/desktop/dist/renderer> --scenes <scenes.mjs> --out <dir> [--only <id-substring>] [--themes light,dark] [--scale 2] [--stub <stub.js>]
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import puppeteer from "puppeteer-core";

const args = Object.fromEntries(process.argv.slice(2).reduce((acc, a, i, all) => (a.startsWith("--") ? [...acc, [a.slice(2), all[i + 1]]] : acc), []));
const dist = path.resolve(args.dist ?? "/home/vercel-sandbox/luke/apps/desktop/dist/renderer");
const out = path.resolve(args.out ?? "out");
const themes = (args.themes ?? "light,dark").split(",");
const scale = Number(args.scale ?? 2);
const stub = fs.readFileSync(args.stub ?? path.join(dist, "stub.js"), "utf8");
const geometry = fs.readFileSync(path.join(path.dirname(new URL(import.meta.url).pathname), "geometry.js"), "utf8");
const { scenes } = await import(path.resolve(args.scenes));
fs.mkdirSync(out, { recursive: true });

const TYPES = { ".html": "text/html", ".js": "text/javascript", ".css": "text/css", ".svg": "image/svg+xml", ".png": "image/png", ".woff2": "font/woff2", ".json": "application/json", ".wasm": "application/wasm" };
const server = http.createServer((req, res) => {
  const file = path.join(dist, decodeURIComponent(new URL(req.url, "http://x").pathname));
  if (!file.startsWith(dist) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) { res.writeHead(404); res.end(); return; }
  res.writeHead(200, { "content-type": TYPES[path.extname(file)] ?? "application/octet-stream" });
  fs.createReadStream(file).pipe(res);
});
await new Promise((r) => server.listen(0, r));
const origin = `http://localhost:${server.address().port}`;

const browser = await puppeteer.launch({ executablePath: "/usr/bin/google-chrome", headless: true, args: ["--no-sandbox", "--font-render-hinting=none"] });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const selected = scenes.filter((s) => !args.only || args.only.split(",").some((o) => s.id.includes(o)));
const report = [];
for (const scene of selected) {
  for (const theme of args["force-themes"] ? themes : (scene.themes ?? themes)) {
    const page = await browser.newPage();
    const errors = [];
    page.on("pageerror", (e) => errors.push(e.message.slice(0, 200)));
    const { width, height = 720 } = scene.window ?? { width: 1160 };
    await page.setViewport({ width, height, deviceScaleFactor: scale });
    await page.emulateMediaFeatures([{ name: "prefers-color-scheme", value: theme }, { name: "prefers-reduced-motion", value: "reduce" }]);
    await page.evaluateOnNewDocument((storage, sceneData) => {
      try { localStorage.clear(); for (const [k, v] of Object.entries(storage)) localStorage.setItem(k, typeof v === "string" ? v : JSON.stringify(v)); } catch {}
      window.__scene = sceneData;
    }, scene.storage ?? {}, scene.data ?? {});
    await page.evaluateOnNewDocument(stub);
    await page.goto(`${origin}/${scene.document ?? "index.html"}`, { waitUntil: "networkidle0" });
    await sleep(scene.settle ?? 900);
    try {
      if (scene.steps) await scene.steps(page, { sleep });
      page.on("console", () => {});
      await sleep(scene.after ?? 500);
    } catch (error) {
      errors.push(`step: ${String(error).slice(0, 200)}`);
    }
    const file = `${scene.id}--${theme}.png`;
    const clip = scene.clip ? await page.evaluate((sel) => { const r = document.querySelector(sel)?.getBoundingClientRect(); return r ? { x: r.x, y: r.y, width: r.width, height: r.height } : null; }, scene.clip) : null;
    await page.screenshot({ path: path.join(out, file), ...(clip ? { clip } : {}) });
    const findings = await page.evaluate(geometry);
    report.push({ id: scene.id, title: scene.title, theme, width, height, file, findings, errors });
    console.log(`${file}: ${findings.length} findings${errors.length ? `, errors: ${errors.join(" | ")}` : ""}`);
    await page.close();
  }
}
fs.writeFileSync(path.join(out, `report${args.only ? "-" + args.only.replace(/[^a-z0-9]/gi, "_") : ""}.json`), JSON.stringify(report, null, 2));
await browser.close();
server.close();
