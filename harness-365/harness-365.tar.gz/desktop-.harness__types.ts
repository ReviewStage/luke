import type { ActKind, ActPayload, ActResultFor } from "@luke/host/acts";

/** An act's answer: a value, or a promise of one. Return `never()` for a long-poll read past its first answer. */
export type Answers = {
  [Kind in ActKind]?: (payload: ActPayload<Kind>, scene: Record<string, unknown>) => ActResultFor<Kind> | Promise<ActResultFor<Kind>>;
};

/** A read the service holds open: never answers. */
export const never = <T,>(): Promise<T> => new Promise<T>(() => undefined);
